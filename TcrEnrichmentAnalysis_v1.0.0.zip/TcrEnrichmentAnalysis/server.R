#the data belongs to Drs. Wong, Gold, and Lewinsohn
#the webtool produced by Eisa Mahyari under the mentorship of Dr. Lewinsohn
#Eisa Mahyari (@eisamahyari), Ph.D. Candidate
#2017 Bioinformatics and Computational Biology (BCB) , Oregon Health & Science University (OHSU)


# Define server logic
function(input, output) {
  

  
  dataset <- reactive({
    #print(input$threshold)
    
    MyDF.clean.PBMC <- subset(MyDF.clean, rep=="PBMC")
    MyDF.clean.PBMC$sum.FreqProd.y <- as.numeric(input$threshold)
    MyDF.clean.BAL <- subset(MyDF.clean, rep=="BAL")
    MyDF.clean.BAL$sum.FreqProd.x <- as.numeric(input$threshold)
    
    if (input$thresholdMin==T){
      #so only the imputed minimum changes
      
      #MyDF.clean.PBMC$sum.FreqProd.x[MyDF.clean.PBMC$sum.FreqProd.x < as.numeric(input$threshold)] <- as.numeric(input$threshold)
      #MyDF.clean.BAL$sum.FreqProd.y[MyDF.clean.BAL$sum.FreqProd.y < as.numeric(input$threshold)] <- as.numeric(input$threshold)
      
      MyDF.clean.Both <- subset(MyDF.clean, rep=="Both")
      
    }  
    if (input$thresholdMin==F){
      
      if(length(MyDF.clean.PBMC$sum.FreqProd.x[MyDF.clean.PBMC$sum.FreqProd.x < as.numeric(input$threshold)])>0){
        MyDF.clean.PBMC$sum.FreqProd.x[MyDF.clean.PBMC$sum.FreqProd.x < as.numeric(input$threshold)] <- as.numeric(input$threshold)
      }
      if(length(MyDF.clean.BAL$sum.FreqProd.y[MyDF.clean.PBMC$sum.FreqProd.y < as.numeric(input$threshold)])>0){
        MyDF.clean.BAL$sum.FreqProd.y[MyDF.clean.PBMC$sum.FreqProd.y < as.numeric(input$threshold)] <- as.numeric(input$threshold)
      }
      
      MyDF.clean.Both <- subset(MyDF.clean, rep=="Both")
      if(length(MyDF.clean.Both$sum.FreqProd.x[MyDF.clean.Both$sum.FreqProd.x < as.numeric(input$threshold)])>0){
        MyDF.clean.Both$sum.FreqProd.x[MyDF.clean.Both$sum.FreqProd.x < as.numeric(input$threshold)] <- as.numeric(input$threshold)
      }
      if(length(MyDF.clean.Both$sum.FreqProd.y[MyDF.clean.Both$sum.FreqProd.y < as.numeric(input$threshold)])>0){
        MyDF.clean.Both$sum.FreqProd.y[MyDF.clean.Both$sum.FreqProd.y < as.numeric(input$threshold)] <- as.numeric(input$threshold)
      }
      
      
      
      
    } 
    a <- rbind(MyDF.clean.PBMC, MyDF.clean.BAL, MyDF.clean.Both)
    
    remove(MyDF.clean.PBMC, MyDF.clean.BAL, MyDF.clean.Both)
    
    a <- subset(a, MortenScore.x <= as.numeric(input$mortenslider[2]))
    #print(as.numeric(input$mortenslider[1]))
    #print(a)
    
    a <- subset(a, MortenScore.x >= as.numeric(input$mortenslider[1]))
    
    a$sum.FreqProd.x <- a$sum.FreqProd.x#*100
    a$sum.FreqProd.y <- a$sum.FreqProd.y#*100
    
    a$Log2.sum.FreqProd.x <- log2(a$sum.FreqProd.x)
    a$Log2.sum.FreqProd.y <- log2(a$sum.FreqProd.y)
    
    b <- merge(head(arrange(subset(a, Donor==as.character(input$donor)),desc(sum.FreqProd.x)), n = as.integer(input$ntop)),
               head(arrange(subset(a, Donor==as.character(input$donor)),desc(sum.FreqProd.y)), n = as.integer(input$ntop)),
               all.x=T, all.y=T)
    remove(a)
    
    return(b)
  })
  

  plotInput <- function(){
    trajs <- levels(dataset()$TRAJ)
    vv <- getPalette(nrow(dataset()))
    palette <- brewer.pal("Greys", n=9)
    #print(c(as.numeric(input$scalesize[1]),as.numeric(input$scalesize[2])))
    #dataset()$sum.FreqProd.SeqSUM
    if(input$legpos){
      legPos = "right"} else {
        legPos = "bottom"
      }
    
    p <- ggplot(dataset()[ order(-dataset()[,"sum.FreqProd.SeqSUM"], dataset()[,1]), ], aes(x=log2(sum.FreqProd.x), y=log2(sum.FreqProd.y), label="")) + 
      geom_point(stat="identity", aes(color=as.factor(CDR3a), name="Tissue", 
                                      size=(sum.FreqProd.SeqSUM))) +  
      scale_size(range = c(as.integer(input$scale[1]),as.integer(input$scale[2])), 
                 limits =  c(c(as.numeric(input$scalesize[1]),as.numeric(input$scalesize[2])))) + 
      scale_x_continuous(limits = input$datarange) + scale_y_continuous(limits = input$datarange) +
      theme_bw() + 
      theme(panel.background = element_rect(fill = "ivory",
                                            colour = "black",
                                            size = 1, linetype = "solid"),
            panel.grid.major = element_line(size = 1, linetype = 'solid',
                                            colour = "ivory2"), 
            panel.grid.minor = element_line(size = .5, linetype = 'solid',
                                            colour = "ivory2"),
            plot.title = element_text(size = rel(3), face="bold", colour = "gray25"),
            axis.text = element_text(size = rel(2), face="bold", colour = "lightcyan4"),
            axis.title.x = element_text(size = rel(2), face="bold", colour = "gray25"),
            axis.title.y = element_text(size = rel(2), face="bold", colour = "gray25"),
            legend.text = element_text(size = rel(1.5)),
            legend.margin = unit(2, "lines"),
            legend.title = element_text(size = rel(1.7), face = "bold",hjust=0),
            legend.position = legPos,
            legend.key.size = unit(2, "lines")) + 
      guides(color = guide_legend(order=1, override.aes = list(size=5),ncol = 3, byrow = TRUE, title.position = "top"),
             size = guide_legend(order=2, title.position = "top"),
             shape = guide_legend(order=3)) + 
      geom_text(size=1) + coord_fixed(ratio=1) +
      ggtitle(paste(paste("Donor:", input$donor," - Top: ", input$ntop," seqs per tissue\n",sep=""), sep="\n")) +
      labs(x="Log2( PBMC Frequency)",y="Log2(BAL Frequency)", size="Freq of BAL + PBMC") +
      scale_color_manual(values = vv, name=paste("CDR3a Seqs (",nrow(dataset()),") CDR3a Seq: Count(PBMC, BAL)\n",sep=""), labels= paste(dataset()$CDR3a, ": (",dataset()$count.x,",",dataset()$count.y,")" ,sep="" ))+ 
      geom_abline(aes(colour="one-to-one"), intercept =0, slope = 1, size = .3, colour="gray25")
    
    
  }
  
  
  
  
  output$plot <- renderPlot({
    print(plotInput())
  })

  # Generate a summary of the data
  output$summary <- renderPrint({
    summary(dataset())
  })

  # Generate an HTML table view of the data
  output$table <- renderTable({
    data.frame(x=dataset())
  })
  
  output$recrange <- renderTable({
    
    d <- as.data.frame(cbind(minimum=floor(log2(min(dataset()$sum.FreqProd.x, dataset()$sum.FreqProd.y))),
                             maximum=ceiling(log2(max(dataset()$sum.FreqProd.x, dataset()$sum.FreqProd.y)))))
    return(d)
    })
  
  
  
  
  output$values <- renderTable({

    c <- as.data.frame(dataset())[, c("CDR3a", "TRAJ", "Donor", "Log2.sum.FreqProd.x", "Log2.sum.FreqProd.y", "sum.FreqProd.x", "sum.FreqProd.y",
                                      "MortenScore.x", "count.x", "count.y", "rep", "sum.FreqProd.MAX", "sum.FreqProd.SeqSUM", "rowcode")]
    
    colnames(c) <- c("CDR3a", "TRAJ", "Donor", "Log2(Freq.PBMC)", "Log2(Freq.BAL)", "%Freq.PBMC", "%Freq.BAL",
                     "MortenScore", "count.PBMC", "count.BAL", "Tropism", "Freq.MAX", "sum.FreqProd.SeqSUM", "rowcode")
    
    
    return(c)
    
  })
  
  output$downloadData <- downloadHandler(
    filename = function() { paste(input$donor, input$ntop, input$mortenslider, input$threshold, '.csv', sep='-') },
    content = function(file) {
      c <- as.data.frame(dataset())[, c("CDR3a", "TRAJ", "Donor", "Log2.sum.FreqProd.x", "Log2.sum.FreqProd.y", "sum.FreqProd.x", "sum.FreqProd.y",
                                        "MortenScore.x", "count.x", "count.y", "rep", "sum.FreqProd.MAX", "sum.FreqProd.SeqSUM", "rowcode")]
      
      colnames(c) <- c("CDR3a", "TRAJ", "Donor", "Log2(Freq.PBMC)", "Log2(Freq.BAL)", "%Freq.PBMC", "%Freq.BAL",
                       "MortenScore", "count.PBMC", "count.BAL", "Tropism", "Freq.MAX", "sum.FreqProd.SeqSUM", "rowcode")
      write.csv(c, file)
    }
  )
  
  output$downloadPlot <- downloadHandler(
    filename = paste(input$donor, input$ntop, input$mortenslider, input$threshold, '.png', sep='-'),
    content = function(file) {
      png(file, height = 1200, width = 1000)
      print(plotInput())
      dev.off()
    })

  
  output$instructions <- renderPrint({
    includeMarkdown("instructions.md.html")
  })
  
  
  
  
}

