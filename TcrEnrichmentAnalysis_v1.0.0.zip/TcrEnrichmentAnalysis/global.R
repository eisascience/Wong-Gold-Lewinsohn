#the data belongs to Drs. Wong, Gold, and Lewinsohn
#the webtool produced by Eisa Mahyari under the mentorship of Dr. Lewinsohn
#Eisa Mahyari (@eisamahyari), Ph.D. Candidate
#2017 Bioinformatics and Computational Biology (BCB) , Oregon Health & Science University (OHSU)





#load the libararies needed, install them if you have not already
library(shiny)
library(data.table)

library(ggplot2)
library(dplyr)
library("RColorBrewer")
library("grid")
library(foreign)



getwd()
#MyDF.clean <- read.csv("data/MyDF.Final.Clean.csv")[,-1]
load("data/MyDF.Final.Clean.RData")

####cleaning of the data i.e., labels, formating etc

MyDF.cleanCount <- (as.data.frame.matrix(table(MyDF.clean$CDR3a, MyDF.clean$Donor)))
colnames(MyDF.cleanCount) <- c("X91", "X1016", "X1020")


#dont need counts greater than 1, already have that in another column
MyDF.cleanCount[MyDF.cleanCount > 1] <- 1
MyDF.cleanCount.rowsums <- rowSums(MyDF.cleanCount)

MyDF.cleanCount$X91[MyDF.cleanCount$X91 >= 1] <-"A"
MyDF.cleanCount$X1016[MyDF.cleanCount$X1016 >= 1] <-"B"
MyDF.cleanCount$X1020[MyDF.cleanCount$X1020 >= 1] <-"C"
MyDF.cleanCount$X91[MyDF.cleanCount$X91 == 0] <-"-"
MyDF.cleanCount$X1016[MyDF.cleanCount$X1016 == 0] <-"-"
MyDF.cleanCount$X1020[MyDF.cleanCount$X1020 == 0] <-"-"

MyDF.cleanCount.rowsumsCode <- apply(MyDF.cleanCount,1,paste,collapse=".")


MyDF.cleanCount$rowsum <- as.factor(MyDF.cleanCount.rowsums)
MyDF.cleanCount$rowcode <- as.factor(MyDF.cleanCount.rowsumsCode)
MyDF.cleanCount$CDR3a <- as.factor(rownames(MyDF.cleanCount))

remove(MyDF.cleanCount.rowsumsCode, MyDF.cleanCount.rowsums)

MyDF.clean <- merge(MyDF.cleanCount[,c(4,5,6)], MyDF.clean, by="CDR3a")

remove(MyDF.cleanCount)

#colnames(MyDF.clean)
MyDF.clean$MortenScore.x <- round(as.numeric(MyDF.clean$MortenScore.x)*100,3)
MyDF.clean$MortenScore.y <- round(as.numeric(MyDF.clean$MortenScore.y)*100,3)


MyDF.clean.notBothMor0 <- MyDF.clean[!(MyDF.clean$MortenScore.x == 0  & MyDF.clean$MortenScore.y ==0),]

MyDF.clean.notBothMor0[MyDF.clean.notBothMor0$MortenScore.x == 0,]$MortenScore.x <- MyDF.clean.notBothMor0[MyDF.clean.notBothMor0$MortenScore.x == 0,]$MortenScore.y

MyDF.clean.notBothMor0[MyDF.clean.notBothMor0$MortenScore.y == 0,]$MortenScore.y <- MyDF.clean.notBothMor0[MyDF.clean.notBothMor0$MortenScore.y == 0,]$MortenScore.x

MyDF.clean <- rbind(MyDF.clean.notBothMor0,MyDF.clean[(MyDF.clean$MortenScore.x == 0  & MyDF.clean$MortenScore.y ==0),])

remove(MyDF.clean.notBothMor0)

MyDF.clean$Donor <- factor(MyDF.clean$Donor, labels=c("A: 91", "B: 1016", "C: 1020"))


getPalette = colorRampPalette(brewer.pal(9, "Set1"))

trajs <- sort(unique(as.character(MyDF.clean$TRAJ)), decreasing = FALSE)

donors <- sort(unique(as.character(MyDF.clean$Donor)),decreasing = FALSE)
tissues <- unique(cbind(levels(MyDF.clean$Tissue.x), levels(MyDF.clean$Tissue.y)))[1,]
topn <- c(3, 5, 10, 15, 20, 25, 50, 100)
#xrange <- c(-20,20); yrange <- xrange

colnames(MyDF.clean)

mortS <- MyDF.clean$MortenScore.x

thresholds <- sort(c(1e-6, 5e-6, 5e-5, 1e-5, 5e-4, 1e-4, 5e-3, 1e-3, 5e-2, 1e-2, 1e-1))



