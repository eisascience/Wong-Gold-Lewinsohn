#the data belongs to Drs. Wong, Gold, and Lewinsohn
#the webtool produced by Eisa Mahyari under the mentorship of Dr. Lewinsohn
#Eisa Mahyari (@eisamahyari), Ph.D. Candidate
#2017 Bioinformatics and Computational Biology (BCB) , Oregon Health & Science University (OHSU)



library(shiny)

# Define UI
fluidPage(
  
  # Application title
  titlePanel("TCR Enrichment Analysis (TEA)"),
  
  # Sidebar with controls to select the random distribution type
  # and number of observations to generate. Note the use of the
  # br() element to introduce extra vertical spacing
  
  
  sidebarLayout(
    sidebarPanel(
      
      tags$div(title="Download a CSV of the data represented by the visualization",
               downloadButton('downloadData', 'Download Table (csv)')),
      tags$div(title="Download a PNG of the visualization",
               downloadButton('downloadPlot', 'Download Plot (png)')),
      
      tags$div(title="Select a donor",
               selectInput('donor', 'Donor', donors, selected="C: 1020")),
      tags$div(title="Select a number to find the top N BAL & top N PBMC by freq",
               selectInput('ntop', 'Top "N" Seqs', topn, selected = 10)),
      tags$div(title="Impute seqs with 0/NA & threshold frequencies to be greater or equal to value",
               selectInput('threshold', 'Minimum Technical Threshold', thresholds, selected=1e-3)),
      tags$div(title="If checked, only 0/NA get imputed, no minimum threshold is set",
               checkboxInput("thresholdMin", "Threshold the Monotropic seqs ONLY", F)),
      tags$div(title="Morten Score: sequence probability match to known MAIT TCR seqs",
               sliderInput("mortenslider", "Morten Score", min = 0, max = 100, value = c(95, 100))),
      
      h5("Suggested X-Y range"),
      
      tags$div(title="Choose your X-Y range based on these recommended limits",
               tableOutput("recrange")),
      
      tags$div(title="Choose X-Y range in Log2()",
               sliderInput("datarange", "X-Y range", min = -40, max = 10, value = c(-11, -1))), 

      tags$div(title="Adjust the scale with of the bubble size; i.e., how small is the smallest & how big is the biggest",
               sliderInput("scale", "Bubble visualization scale", min = 1, max = 80, value = c(5, 55))),
      tags$div(title="Adjust the min & max values for Bubbles",
               sliderInput("scalesize", "Bubble size Min-Max range", min = 0, max = .2, value = c(0, .08))),             
      tags$div(title="If checked, legend is on the right of figure",
               checkboxInput("legpos", "Legend on right", F)),                                 
      
      br()
    ),
    
    # Show a tabset that includes a plot, summary, and table view
    # of the generated distribution
    mainPanel(
      tabsetPanel(type = "tabs", 
                  tabPanel("Plot", plotOutput('plot', height = 1200, width = 1000)), 
                  tabPanel("Summary", verbatimTextOutput("summary")), 
                  tabPanel("Table", tableOutput("values")), 
                  tabPanel("Instructions", fluidPage(htmlOutput('instructions'))))
      )
  )
)

